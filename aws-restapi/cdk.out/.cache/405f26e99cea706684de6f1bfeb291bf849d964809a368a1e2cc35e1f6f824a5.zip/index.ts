exports.handler = async(event) => {
    console.log(event)
    // switch(event.info.fieldName) {
    //     case "createTodo":
    //         return await createTodo(event.arguments.todosInput);

    //     case "deleteTodo":
    //         return await deleteTodo(event.arguments.thatId);

    //     case "updateTodo":
    //         return await updateTodo(event.arguments.todosInput);

    //     case "allTodos":
    //         return await allTodos();
        
    //     default:
    //         return null;
    // }
}