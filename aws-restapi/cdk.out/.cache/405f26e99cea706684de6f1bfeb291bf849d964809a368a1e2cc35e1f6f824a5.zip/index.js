"use strict";
exports.handler = async (event) => {
    console.log(event);
    // switch(event.info.fieldName) {
    //     case "createTodo":
    //         return await createTodo(event.arguments.todosInput);
    //     case "deleteTodo":
    //         return await deleteTodo(event.arguments.thatId);
    //     case "updateTodo":
    //         return await updateTodo(event.arguments.todosInput);
    //     case "allTodos":
    //         return await allTodos();
    //     default:
    //         return null;
    // }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxDQUFDLE9BQU8sR0FBRyxLQUFLLEVBQUMsS0FBSyxFQUFFLEVBQUU7SUFDN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNsQixpQ0FBaUM7SUFDakMseUJBQXlCO0lBQ3pCLCtEQUErRDtJQUUvRCx5QkFBeUI7SUFDekIsMkRBQTJEO0lBRTNELHlCQUF5QjtJQUN6QiwrREFBK0Q7SUFFL0QsdUJBQXVCO0lBQ3ZCLG1DQUFtQztJQUVuQyxlQUFlO0lBQ2YsdUJBQXVCO0lBQ3ZCLElBQUk7QUFDUixDQUFDLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnRzLmhhbmRsZXIgPSBhc3luYyhldmVudCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGV2ZW50KVxuICAgIC8vIHN3aXRjaChldmVudC5pbmZvLmZpZWxkTmFtZSkge1xuICAgIC8vICAgICBjYXNlIFwiY3JlYXRlVG9kb1wiOlxuICAgIC8vICAgICAgICAgcmV0dXJuIGF3YWl0IGNyZWF0ZVRvZG8oZXZlbnQuYXJndW1lbnRzLnRvZG9zSW5wdXQpO1xuXG4gICAgLy8gICAgIGNhc2UgXCJkZWxldGVUb2RvXCI6XG4gICAgLy8gICAgICAgICByZXR1cm4gYXdhaXQgZGVsZXRlVG9kbyhldmVudC5hcmd1bWVudHMudGhhdElkKTtcblxuICAgIC8vICAgICBjYXNlIFwidXBkYXRlVG9kb1wiOlxuICAgIC8vICAgICAgICAgcmV0dXJuIGF3YWl0IHVwZGF0ZVRvZG8oZXZlbnQuYXJndW1lbnRzLnRvZG9zSW5wdXQpO1xuXG4gICAgLy8gICAgIGNhc2UgXCJhbGxUb2Rvc1wiOlxuICAgIC8vICAgICAgICAgcmV0dXJuIGF3YWl0IGFsbFRvZG9zKCk7XG4gICAgICAgIFxuICAgIC8vICAgICBkZWZhdWx0OlxuICAgIC8vICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgLy8gfVxufSJdfQ==