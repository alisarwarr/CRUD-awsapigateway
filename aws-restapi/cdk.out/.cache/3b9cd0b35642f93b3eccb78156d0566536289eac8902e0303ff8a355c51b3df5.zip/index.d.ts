declare const AWS: any;
declare const docClient: any;
declare const TABLE_NAME: string;
